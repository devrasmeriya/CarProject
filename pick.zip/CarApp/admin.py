from django.contrib import admin
from CarApp.models import CarModel

# Register your models here.
admin.register(CarModel)
