from django.apps import AppConfig


class CarappConfig(AppConfig):
    name = 'CarApp'
